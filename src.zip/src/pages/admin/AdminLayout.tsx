import { Outlet, Link } from "react-router-dom";

export default function AdminLayout() {
  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
        <h2 style={{ margin: 0 }}>Admin</h2>
        <Link to="/admin">Dashboard</Link>
        <Link to="/admin/wizard">Create Quiz Wizard</Link>
        <Link to="/admin/quizzes/new">Create Quiz (simple)</Link>
        <a href="/logout">Logout</a>
      </div>

      <hr style={{ margin: "16px 0" }} />

      <Outlet />
    </div>
  );
}
